N = int(input("请输入整数N:"))
sum_1toN = 0
for i in range(1,N+1):
    sum_1toN += i
print('The sum from 1 to N is: ', sum_1toN)
5